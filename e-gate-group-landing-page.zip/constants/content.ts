
// =======================================================================
// المحتوى النصي للموقع | Website Text Content
// =======================================================================
// يمكنك تعديل جميع النصوص في هذا الملف بسهولة.
// You can easily edit all the text content in this file.
// =======================================================================

import { Feature, Testimonial, FaqItem, ProblemPoint, Step, PaymentMethod, ActivityType, FeeDetail } from "../types";

// COMPANY INFO
export const COMPANY_NAME = "E-Gate Group";
export const COMPANY_SLOGAN = "تفعيل بوابات الدفع بدون تعقيد";

// CALL TO ACTION BUTTONS
export const CTA_PRIMARY_TEXT = "قدّم طلب تفعيل بوابة الدفع";
export const CTA_SECONDARY_TEXT = "شاهد التفاصيل قبل القرار";

// HERO SECTION
export const HERO_CONTENT = {
    badge: "للأفراد والشركات",
    title: "فعّل بوابة الدفع لمشروعك بدون تعقيد",
    subtitle: "نوفر حلول دفع إلكترونية آمنة وسريعة للأفراد والشركات، مصممة لتناسب احتياجات نشاطك.",
    description: "نساعدك على تجاوز الإجراءات المعقدة ونوفر لك بوابة دفع مستقرة تتميز بالوضوح في الرسوم وسرعة في الربط، لتركز على نمو مشروعك.",
    metrics: [
        { title: "تفعيل سريع", description: "إجراءات مبسطة لتفعيل بوابة الدفع على متجرك خلال 24 ساعة." },
        { title: "رسوم واضحة", description: "لا توجد رسوم خفية. شفافية كاملة في كل معاملة." },
        { title: "دعم متكامل", description: "فريق تقني متخصص لمساعدتك في كل خطوة." },
    ]
};

// PAYMENT LOGOS
// أضف أو أزل أيقونات بوابات الدفع هنا
// Add or remove payment gateway icons here
export const PAYMENT_METHODS: PaymentMethod[] = [
    { name: "Visa", icon: "visa" },
    { name: "Mastercard", icon: "mastercard" },
    { name: "Mada", icon: "mada" },
    { name: "American Express", icon: "amex" },
    { name: "Apple Pay", icon: "applepay" },
    { name: "Google Pay", icon: "googlepay" },
    { name: "Knet", icon: "knet" },
];

// PROBLEM SECTION
export const PROBLEM_SECTION = {
    title: "لماذا تفعيل بوابات الدفع يمثل تحديًا؟",
    points: [
        {
            title: "إجراءات معقدة",
            description: "الحاجة لتقديم سجلات تجارية ووثائق متعددة قد لا تتوفر لدى الجميع."
        },
        {
            title: "رفض متكرر",
            description: "رفض الطلبات لأسباب غير واضحة أو لعدم تطابق النشاط مع شروط البنوك."
        },
        {
            title: "متطلبات صارمة",
            description: "اشتراطات تقنية ومالية عالية يصعب على المشاريع الناشئة تحقيقها."
        },
        {
            title: "غموض الرسوم",
            description: "عدم وضوح رسوم التأسيس والرسوم المتغيرة لكل عملية، مما يصعّب التخطيط المالي."
        }
    ] as ProblemPoint[]
};

// FEATURES SECTION
export const FEATURES_SECTION = {
    title: "حلول دفع مصممة لنجاحك",
    features: [
        {
            title: "ربط تقني سريع",
            description: "إضافة جاهزة لربط سريع مع متجرك.",
            icon: "zap"
        },
        {
            title: "متطلبات مبسطة",
            description: "نتجنب التعقيدات. متطلباتنا واضحة ومصممة لتسهيل عملية التفعيل السريع لمشروعك.",
            icon: "clipboard"
        },
        {
            title: "وضوح تام في الرسوم",
            description: "تعرف على رسومك بوضوح. لا مفاجآت في كشف حسابك.",
            icon: "filetext"
        },
        {
            title: "دعم عملات متعددة",
            description: "استقبل المدفوعات من عملائك حول العالم بعملات مختلفة بسهولة.",
            icon: "currency"
        },
        {
            title: "حلول قابلة للتوسع",
            description: "بوابة دفع تنمو مع مشروعك، قادرة على التعامل مع آلاف المعاملات يوميًا.",
            icon: "barchart"
        },
        {
            title: "متابعة ودعم فني",
            description: "دعم متخصص جاهز لمساعدتك في حل أي مشكلة تقنية تواجهك.",
            icon: "headset"
        }
    ] as Feature[]
};

// USP SECTION (Individuals & Businesses)
export const USP_SECTION = {
    title: "هل يجب أن أمتلك شركة؟",
    content: "نفهم أن طبيعة المشاريع تختلف. لذلك، نوفر المرونة في المتطلبات:",
    points: [
        "سواءً كنت شركة أو مشروعًا فرديًا، فخدمتنا ستكون مخصصة لقطاع عملك.",
        "المتطلبات مبسطة لتسهيل عملية الربط وتفعيل البوابة خلال 24 ساعة فقط."
    ]
};

// SOCIAL PROOF / TESTIMONIALS
// يمكنك تعديل أو إضافة آراء العملاء هنا
export const TESTIMONIALS_SECTION = {
    title: "ماذا يقول عملاؤنا",
    testimonials: [
        {
            quote: "تعامل راقٍ، سرعة في إنجاز المعاملات ومصداقية عالية. شكرًا لكم.",
            author: "Obaidah Academy",
            role: "منصة تعليمية"
        },
        {
            quote: "واجهتنا مشكلة تقنية بسيطة أثناء الربط، وكان الفريق التقني احترافيًا وسريع الاستجابة. تم حل المشكلة في دقائق. خدمة عملاء ممتازة!",
            author: "مدير تقني في شركة ناشئة",
            role: "حلول برمجية (SaaS)"
        },
        {
            quote: "أفضل ما فيهم هو الشفافية. الرسوم واضحة منذ البداية ولم أواجه أي مشاكل. أنصح بهم بشدة لأي متجر إلكتروني.",
            author: "صاحب متجر إلكتروني",
            role: "تجارة إلكترونية"
        }
    ] as Testimonial[]
};


// PRICING SECTION
export const PRICING_SECTION = {
    title: "رسوم واضحة ومباشرة",
    description: "نؤمن بالشفافية الكاملة. إليك تفاصيل هيكل الرسوم لدينا بدون أي مفاجآت.",
    showPlans: false, 
    feeDetails: [
        {
            title: "رسوم تأسيس (مرة واحدة)",
            description: "تدفع لمرة واحدة فقط لتفعيل البوابة على متجرك، وتختلف حسب نوع النشاط.",
            icon: "settings"
        },
        {
            title: "اشتراك رمزي (1$ يوميًا)",
            description: "لضمان استمرارية الخدمة وتغطية تكاليف الدعم التقني والتحديثات المستمرة.",
            icon: "repeat"
        },
        {
            title: "عمولة على المبيعات (15%)",
            description: "عمولة واضحة وثابتة على كل عملية بيع ناجحة تتم عبر بوابتك.",
            icon: "percent"
        }
    ] as FeeDetail[],
    plans: []
};


// STEPS SECTION
export const STEPS_SECTION = {
    title: "3 خطوات بسيطة لتفعيل بوابتك",
    steps: [
        {
            name: "تعبئة النموذج",
            description: "املأ نموذج الطلب بمعلوماتك الأساسية ومعلومات مشروعك."
        },
        {
            name: "تقييم سريع",
            description: "يقوم فريقنا بمراجعة طلبك وتحديد الحل الأنسب لك خلال 48 ساعة."
        },
        {
            name: "التفعيل والربط",
            description: "بعد الموافقة، نزودك بالبيانات اللازمة لربط بوابة الدفع وبدء استقبال الأموال."
        }
    ] as Step[]
};

// FAQ SECTION
export const FAQ_SECTION = {
    title: "أسئلة شائعة",
    faqs: [
        {
            question: "مبلغ التأسيس مقابل ماذا؟",
            answer: "مقابل تفعيل بوابة الدفع لعنوان متجر واحد. ويختلف المبلغ حسب نوع المنتجات (رقمية أو ملموسة) وطبيعة النشاط."
        },
        {
            question: "الاشتراك اليومي 1$ مقابل ماذا؟",
            answer: "مقابل المصاريف التقنية المستمرة، وتأمين روابط دفع احتياطية. اشتراك رمزي يضمن المتابعة والدعم الفني بشكل دائم."
        },
        {
            question: "عمولة المبيعات 15% تشمل ماذا؟",
            answer: "تشمل عمولات بوابة الدفع، ضريبة الأرباح، وتكاليف التحويل للتاجر بالدولار. قبول البطاقات البنكية يعتبر تصريحًا ضريبيًا كاملاً، لذلك تُحتسب الرسوم مباشرة."
        },
        {
            question: "هل يوجد عمولات إضافية؟",
            answer: "لا توجد عمولات إضافية إلا عند العمل بالليرة التركية، حيث قد يُطلب تقديم فواتير شراء قبل استلام المستحقات."
        },
        {
            question: "هل يمكن إلغاء الخدمة؟",
            answer: "رسوم التأسيس غير مستردة، لكن يمكنك إيقاف الاشتراك اليومي 1$ في أي وقت."
        },
        {
            question: "كم مدة استلام قيمة المبيعات؟",
            answer: "عادةً يتم تسليم المبالغ خلال 7 أيام. للمنتجات الملموسة يجب تقديم إثبات الشحن والتسليم."
        },
        {
            question: "هل يمكن للبوابة مصادرة قيمة المبيعات؟",
            answer: "لا يتم الحجز أو المصادرة إلا في حالة بيع منتجات وهمية أو مخالفة واضحة. يمكن تجنب أي مخاطر باتباع النصائح المبنية على تجارب سابقة."
        },
        {
            question: "من يتحمل ضريبة القيمة المضافة (VAT)؟",
            answer: "المستهلك النهائي هو من يتحمل الضريبة. وتختلف نسبتها من بلد لآخر حسب الأنظمة الضريبية."
        }
    ] as FaqItem[]
};

// LEAD FORM SECTION
export const LEAD_FORM_SECTION = {
    title: "ابدأ الآن",
    subtitle: "املأ النموذج أدناه وسيقوم أحد خبرائنا بالتواصل معك في أقرب وقت ممكن.",
    // استبدل 'YOUR_FORM_ID' بمعرف الفورم الخاص بك من Formspree
    // Replace 'YOUR_FORM_ID' with your actual Formspree form ID
    formspreeId: "YOUR_FORM_ID"
};

// FORM FIELDS & LABELS
export const FORM_LABELS = {
    fullName: "الاسم الكامل",
    customerType: "نوع العميل",
    individual: "فرد",
    business: "شركة",
    projectName: "اسم المشروع/الشركة (اختياري)",
    country: "الدولة",
    activityType: "نوع النشاط",
    email: "البريد الإلكتروني",
    whatsapp: "رقم واتساب (اختياري)",
    website: "رابط الموقع/الصفحة (اختياري)",
    message: "رسالة مختصرة",
    submitButton: "إرسال الطلب",
    submittingButton: "جاري الإرسال...",
    successMessage: "تم استلام طلبك بنجاح! سنتواصل معك قريبًا.",
    errorMessage: "حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى."
};

// قائمة أنواع الأنشطة للنموذج
export const ACTIVITY_TYPES: ActivityType[] = [
    { value: "ecommerce", label: "تجارة إلكترونية (منتجات ملموسة)" },
    { value: "digital_products", label: "منتجات رقمية (دورات، كتب، برمجيات)" },
    { value: "saas", label: "خدمات برمجية (SaaS)" },
    { value: "services", label: "خدمات مهنية (استشارات، تصميم، تطوير)" },
    { value: "booking", label: "حجوزات (فنادق، طيران، فعاليات)" },
    { value: "other", label: "أخرى (يرجى التوضيح في الرسالة)" },
];

// FOOTER
export const FOOTER_TEXT = `© ${new Date().getFullYear()} ${COMPANY_NAME}. جميع الحقوق محفوظة.`;