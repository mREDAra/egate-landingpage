
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import PaymentLogos from './components/PaymentLogos';
import Problem from './components/Problem';
import Features from './components/Features';
import UspSection from './components/UspSection';
import SocialProof from './components/SocialProof';
import Pricing from './components/Pricing';
import Steps from './components/Steps';
import Faq from './components/Faq';
import LeadForm from './components/LeadForm';
import Footer from './components/Footer';
import AnimatedSection from './components/AnimatedSection';
import { CTA_PRIMARY_TEXT } from './constants/content';

const StickyCTA: React.FC = () => (
  <div className="sm:hidden fixed bottom-0 left-0 right-0 bg-[#0A192F]/80 backdrop-blur-lg p-4 z-40 border-t border-slate-700">
    <a
      href="#lead-form"
      className="w-full text-center block bg-[#10b981] text-white font-bold py-3 px-8 rounded-lg hover:bg-[#0f9a6d] transition-colors duration-300"
    >
      {CTA_PRIMARY_TEXT}
    </a>
  </div>
);


const App: React.FC = () => {
  return (
    <div className="bg-[#0A192F] text-slate-300 overflow-x-hidden">
      <Header />
      <main>
        <Hero />
        <PaymentLogos />
        <AnimatedSection>
          <Problem />
        </AnimatedSection>
        <AnimatedSection>
          <Features />
        </AnimatedSection>
        <AnimatedSection>
          <UspSection />
        </AnimatedSection>
        <AnimatedSection>
          <SocialProof />
        </AnimatedSection>
        <AnimatedSection>
          <Pricing />
        </AnimatedSection>
        <AnimatedSection>
          <Steps />
        </AnimatedSection>
        <AnimatedSection>
          <Faq />
        </AnimatedSection>
        <AnimatedSection>
          <LeadForm />
        </AnimatedSection>
      </main>
      <Footer />
      <StickyCTA />
    </div>
  );
};

export default App;