
import React from 'react';
import { USP_SECTION, CTA_PRIMARY_TEXT } from '../constants/content';

const CheckIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5 text-[#10b981] ml-3 flex-shrink-0">
        <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
);


const UspSection: React.FC = () => {
    return (
        <section className="py-20 md:py-28">
            <div className="container mx-auto px-6">
                <div className="max-w-4xl mx-auto bg-slate-800/50 border border-slate-700 rounded-lg p-8 md:p-12 text-center">
                    <h2 className="text-3xl md:text-4xl font-extrabold text-slate-100 mb-4">
                        {USP_SECTION.title}
                    </h2>
                    <p className="text-slate-400 text-lg mb-8 max-w-2xl mx-auto">
                        {USP_SECTION.content}
                    </p>
                    <div className="text-right inline-block mx-auto space-y-4 mb-10">
                        {USP_SECTION.points.map((point, index) => (
                            <div key={index} className="flex items-start">
                                <CheckIcon />
                                <span className="text-slate-300">{point}</span>
                            </div>
                        ))}
                    </div>
                    <div>
                        <a
                            href="#lead-form"
                            className="bg-[#10b981] text-white font-bold py-3 px-8 rounded-lg hover:bg-[#0f9a6d] transition-colors duration-300"
                        >
                            {CTA_PRIMARY_TEXT}
                        </a>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default UspSection;
