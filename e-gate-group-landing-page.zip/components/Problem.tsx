
import React from 'react';
import { PROBLEM_SECTION } from '../constants/content';
import { ProblemPoint } from '../types';

const ProblemIcon: React.FC = () => (
    <div className="bg-[#10b981]/10 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#10b981]">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
    </div>
);


const Problem: React.FC = () => {
    return (
        <section id="problem" className="py-20 md:py-28 bg-[#0A192F]">
            <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto">
                    <h2 className="text-3xl md:text-4xl font-extrabold text-slate-100 mb-4">
                        {PROBLEM_SECTION.title}
                    </h2>
                </div>

                <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                    {PROBLEM_SECTION.points.map((point: ProblemPoint, index: number) => (
                        <div key={index} className="bg-slate-800/50 p-8 rounded-lg border border-slate-700 text-right">
                            <ProblemIcon />
                            <h3 className="text-xl font-bold text-slate-100 mb-2">{point.title}</h3>
                            <p className="text-slate-400">{point.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Problem;
