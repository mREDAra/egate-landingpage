
import React from 'react';
import { HERO_CONTENT, CTA_PRIMARY_TEXT, CTA_SECONDARY_TEXT } from '../constants/content';
import { Metric } from '../types';

const Hero: React.FC = () => {
  return (
    <section className="py-20 md:py-32">
      <div className="container mx-auto px-6 text-center">
        <div className="inline-block bg-[#10b981]/10 text-[#10b981] text-sm font-bold px-4 py-1 rounded-full mb-4">
          {HERO_CONTENT.badge}
        </div>
        <h1 className="text-4xl md:text-6xl font-extrabold text-slate-100 mb-4 leading-tight">
          {HERO_CONTENT.title}
        </h1>
        <p className="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto mb-8">
          {HERO_CONTENT.subtitle}
        </p>
        <div className="flex justify-center items-center gap-4 flex-wrap">
          <a
            href="#lead-form"
            className="bg-[#10b981] text-white font-bold py-3 px-8 rounded-lg hover:bg-[#0f9a6d] transition-colors duration-300"
          >
            {CTA_PRIMARY_TEXT}
          </a>
          <a
            href="#features"
            className="bg-slate-700 text-slate-200 font-bold py-3 px-8 rounded-lg hover:bg-slate-600 transition-colors duration-300"
          >
            {CTA_SECONDARY_TEXT}
          </a>
        </div>
        <div className="mt-16 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-right">
          {HERO_CONTENT.metrics.map((metric: Metric, index: number) => (
            <div key={index} className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-bold text-slate-100 mb-2">{metric.title}</h3>
              <p className="text-slate-400">{metric.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
