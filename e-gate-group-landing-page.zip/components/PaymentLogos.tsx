
import React from 'react';
import { PAYMENT_METHODS } from '../constants/content';
import { PaymentMethod } from '../types';

const Icon: React.FC<{ name: string }> = ({ name }) => {
  const iconStyle = "h-8 md:h-10 text-gray-400";
  switch (name) {
    case 'visa':
      return <svg className={iconStyle} fill="currentColor" role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7.123 18.06h2.122l1.015-4.234c.102-.42.22-.897.31-1.42h.04c.053.333.14.714.262 1.153l.69 4.5h2.09l3.14-12.12h-2.24l-1.123 5.343c-.086.4-.15.75-.204 1.05h-.04c-.05-.286-.12-.65-.21-1.09l-.7-5.303h-1.9L8.353 6.024l-1.23 12.035zM22.03 5.94h-1.332c-.53 0-.874.167-1.05.51l-2.98 11.61h2.26l.48-1.92h2.58l.26 1.92h2.06L22.03 5.94zm-1.47 7.95l.93-3.87.57 3.87h-1.5zM4.11 5.94l-2.5 12.12H0L2.5 5.94H4.11z"></path></svg>;
    case 'mastercard':
      return <svg className={iconStyle} viewBox="0 0 212 131"><path fill="#FF5F00" d="M123.33 65.5A65.5 65.5 0 1 1 25.13 40.3a65.52 65.52 0 0 1 98.2 25.2Z"></path><path fill="#EB001B" d="M212 65.5a65.5 65.5 0 1 1-131 0 65.5 65.5 0 0 1 131 0Z"></path><path fill="#F79E1B" d="M168.83 65.5a65.5 65.5 0 0 1-87.16 55.45 65.5 65.5 0 0 0 0-110.9 65.5 65.5 0 0 1 87.16 55.45Z"></path></svg>;
    case 'applepay':
      return <svg className={iconStyle} fill="currentColor" role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M14.471 16.015c.618 0 1.235-.15 1.815-.436.953-.464 1.7-1.31 2.22-2.433.518-1.122.75-2.433.687-3.816h-3.23c-.027 1.25-.33 2.31-.85 3.125-.52.815-1.21 1.26-2.13 1.26-.88 0-1.52-.403-1.95-1.08-.428-.675-.6-1.45-.55-2.525v-3.95h-3.243v3.9c0 2.25.814 3.87 2.37 4.8.96.6 2.115.935 3.396.935zm4.842-10.72c-1.025-.01-2.025.29-2.9.82-.574.34-1.1.79-1.55 1.32-.45-.53-1.004-.98-1.57-1.32-.91-.5-1.87-.76-2.89-.72-1.636-.05-3.21.57-4.43 1.72-.8.75-1.38 1.72-1.7 2.82-1.28 4.42.82 8.96 3.12 11.82.9.89 1.95 1.57 3.1 1.95.14.04.28.06.42.06.1 0 .2-.01.3-.03.05-.01.1-.02.15-.04 1.29-.4 2.45-1.12 3.3-2.05 2.1-2.28 3.5-5.5 2.4-9.02-.4-1.2-1.1-2.2-2-3-.3-.2-.5-.3-.8-.5z"></path></svg>;
    case 'googlepay':
      return <svg className={iconStyle} viewBox="0 0 80 48"><g clipPath="url(#clip0_1_2)"><path d="M26.4 22.8V20.4H15.6V36.3H19.3V29.6H25.5V26.7H19.3V22.8H26.4Z" fill="#5F6368"/><path d="M37.3 20.4H31.9V36.3H35.6V30.1H37.3C41.2 30.1 44.4 27.6 44.4 23.7V23.6C44.4 21.6 42.8 20.4 41.2 20.4H37.3ZM37.3 26.5H35.6V24.1H37.3C38.6 24.1 39.7 25.1 39.7 26.5C39.7 26.5 39.7 26.5 39.7 26.5C39.7 27.8 38.6 28.9 37.3 28.9V26.5Z" fill="#5F6368"/><path d="M49.3 20.4H43.9V36.3H47.6V30.1H49.3C53.2 30.1 56.4 27.6 56.4 23.7V23.6C56.4 21.6 54.8 20.4 53.2 20.4H49.3ZM49.3 26.5H47.6V24.1H49.3C50.6 24.1 51.7 25.1 51.7 26.5C51.7 26.5 51.7 26.5 51.7 26.5C51.7 27.8 50.6 28.9 49.3 28.9V26.5Z" fill="#5F6368"/><path d="M74 16.7H61.3V20.4H74V16.7Z" fill="#5F6368"/><path d="M68.7 20.4C66.1 20.4 64 22.5 64 25.1V32.3C64 34.9 66.1 37 68.7 37H74V28.5H68.7V25.1H74V20.4H68.7ZM68.7 33.3H67.7V28.5H68.7C70.1 28.5 71.2 29.6 71.2 30.9C71.2 32.2 70.1 33.3 68.7 33.3Z" fill="#5F6368"/><path d="M12.2 20.4C12.2 18.4 13.8 16.7 15.9 16.7C16.9 16.7 17.8 17.1 18.5 17.8L16.4 19.9C16.2 19.7 15.9 19.6 15.6 19.6C14.8 19.6 14.1 20.2 14.1 21.1C14.1 21.9 14.8 22.6 15.6 22.6C15.9 22.6 16.2 22.4 16.4 22.2L18.5 24.3C17.8 24.9 16.9 25.3 15.9 25.3C13.8 25.3 12.2 23.7 12.2 21.7V20.4Z" fill="#EA4335"/><path d="M6 20.4H9.7V31.5C9.7 33.5 11.3 35.2 13.4 35.2H13.6C13.6 33.2 12 31.5 12 31.5H12C11.9 31.5 11.9 31.5 11.8 31.5H11.2V24.1H6V20.4Z" fill="#4285F4"/><path d="M8.5 16.7C6.4 16.7 4.8 18.3 4.8 20.4C4.8 22.2 6.1 23.7 7.9 24V16.8C6.1 17.1 4.8 18.6 4.8 20.4C4.8 22.4 6.4 24.1 8.5 24.1C10.6 24.1 12.2 22.4 12.2 20.4V20.4C12.2 18.3 10.6 16.7 8.5 16.7Z" fill="#FBBC04"/><path d="M8.3 16.8C6.3 16.8 4.6 18.4 4.6 20.5C4.6 22.3 5.9 23.8 7.7 24.1V16.8C6.1 17.1 4.8 18.6 4.8 20.4C4.8 22.5 6.5 24.3 8.7 24.3C10.8 24.3 12.4 22.7 12.4 20.5C12.4 18.4 10.5 16.8 8.3 16.8Z" fill="#34A853"/></g><defs><clipPath id="clip0_1_2"><rect width="69.2" height="20.9" fill="white" transform="translate(4.8 16.4)"/></clipPath></defs></svg>;
    case 'mada':
      return <svg className={iconStyle} viewBox="0 0 100 60"><path fill="#00AEEF" d="M0 0h100v60H0z"></path><path fill="#FFF" d="m15 15h70v30H15z"></path><path fill="none" stroke="#6D2E80" strokeWidth="2" strokeMiterlimit="10" d="M30 30c0-5.5 4.5-10 10-10 2.8 0 5.2 1.1 7.1 2.9"></path><path fill="none" stroke="#8DC63F" strokeWidth="2" strokeMiterlimit="10" d="M70 30c0 5.5-4.5 10-10 10-2.8 0-5.2-1.1-7.1-2.9"></path></svg>;
    case 'amex':
      return <svg className={iconStyle} fill="currentColor" role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M22.26 22.26H1.74V1.74h20.52v20.52zM12 5.482H6.015l-1.63 3.315h7.6zM12 10.542H4.385l-1.63 3.315H12zm0 5.06H2.755l-1.015 2.158H12zM12 5.482V1.74H1.74l10.26 20.52V5.482zm.015 0l3.9-3.74h-3.9v3.74zm-.015 1.742v3.315l5.06-5.055H12v1.74zm0 5.06V8.967l6.755-6.755v5.06H12zm0 1.74v3.315l8.44-8.44V7.242H12zm0 5.06v-3.315l-1.63 1.63v1.685zm0 1.74v-1.685l-3.315 3.315h3.315V22.26zm0-5.118l3.315-3.315-3.315-3.315v6.63zm0 5.06l5.055-5.06-5.055-5.058v10.118zm0 1.74l6.755-6.755-6.755-6.755v13.51zm0 1.74l8.44-8.44-8.44-8.44v16.88z"/></svg>;
    case 'knet':
      return <svg className={iconStyle} fill="currentColor" role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M3.978 6.945a.75.75 0 01.75-.75h14.544a.75.75 0 01.75.75v10.11a.75.75 0 01-.75.75H4.728a.75.75 0 01-.75-.75V6.945zm.75-2.25a2.25 2.25 0 00-2.25 2.25v10.11a2.25 2.25 0 002.25 2.25h14.544a2.25 2.25 0 002.25-2.25V6.945a2.25 2.25 0 00-2.25-2.25H4.728zM12.75 12a.75.75 0 01.75-.75h4.478a.75.75 0 010 1.5H13.5a.75.75 0 01-.75-.75zM8.228 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM6 12a2.25 2.25 0 114.5 0 2.25 2.25 0 01-4.5 0z"/></svg>;
    default:
      return null;
  }
};


const PaymentLogos: React.FC = () => {
  const logos = PAYMENT_METHODS.map((method: PaymentMethod) => (
    <div key={method.name} title={method.name} className="flex-shrink-0 mx-6 md:mx-8">
      <Icon name={method.icon} />
    </div>
  ));

  return (
    <section className="py-8 bg-slate-800/50">
      <div className="container mx-auto px-6">
        <div className="relative w-full overflow-hidden">
          <div className="flex group">
            <div className="flex items-center flex-shrink-0 group-hover:[animation-play-state:paused] animate-scroll">
              {logos}
            </div>
            <div className="flex items-center flex-shrink-0 group-hover:[animation-play-state:paused] animate-scroll" aria-hidden="true">
              {logos}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PaymentLogos;
