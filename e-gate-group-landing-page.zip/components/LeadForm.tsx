
import React, { useState } from 'react';
import { LEAD_FORM_SECTION, FORM_LABELS, ACTIVITY_TYPES } from '../constants/content';
import { ActivityType } from '../types';

const LeadForm: React.FC = () => {
    const [formData, setFormData] = useState({
        fullName: '',
        customerType: 'individual',
        projectName: '',
        country: '',
        activityType: '',
        email: '',
        whatsapp: '',
        website: '',
        message: ''
    });
    const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({...prev, customerType: e.target.value}));
    };

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setStatus('submitting');

        if (LEAD_FORM_SECTION.formspreeId === 'YOUR_FORM_ID') {
            console.error("Please replace 'YOUR_FORM_ID' in constants/content.ts with your Formspree form ID.");
            setTimeout(() => setStatus('error'), 500);
            return;
        }

        try {
            const response = await fetch(`https://formspree.io/f/${LEAD_FORM_SECTION.formspreeId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                setStatus('success');
                setFormData({
                    fullName: '', customerType: 'individual', projectName: '', country: '', activityType: '',
                    email: '', whatsapp: '', website: '', message: ''
                });
            } else {
                setStatus('error');
            }
        } catch (error) {
            console.error(error);
            setStatus('error');
        }
    };
    
    const inputClasses = "block w-full bg-slate-700 border-slate-600 rounded-md py-2.5 px-3 text-white focus:ring-2 focus:ring-[#10b981] focus:border-[#10b981] outline-none peer placeholder-transparent";
    const labelClasses = "absolute text-sm text-slate-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-slate-700 px-2 right-3 peer-focus:px-2 peer-focus:text-[#10b981] peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4";

    return (
        <section id="lead-form" className="py-20 md:py-28 bg-slate-900/70">
            <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto">
                    <h2 className="text-3xl md:text-4xl font-extrabold text-slate-100 mb-4">{LEAD_FORM_SECTION.title}</h2>
                    <p className="text-lg text-slate-400 mb-12">{LEAD_FORM_SECTION.subtitle}</p>
                </div>
                <div className="max-w-3xl mx-auto bg-slate-800/50 p-8 rounded-lg border border-slate-700">
                    <form onSubmit={handleSubmit} className="space-y-8">
                        {/* Full Name */}
                        <div className="relative">
                            <input type="text" name="fullName" id="fullName" required onChange={handleChange} value={formData.fullName} className={inputClasses} placeholder={FORM_LABELS.fullName} />
                            <label htmlFor="fullName" className={labelClasses}>{FORM_LABELS.fullName}</label>
                        </div>

                        {/* Customer Type */}
                        <div>
                            <label className="block text-sm font-medium text-slate-300 mb-2">{FORM_LABELS.customerType}</label>
                            <div className="flex items-center gap-6">
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="customerType" value="individual" checked={formData.customerType === 'individual'} onChange={handleRadioChange} className="form-radio" />
                                    <span className="text-slate-200">{FORM_LABELS.individual}</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="customerType" value="business" checked={formData.customerType === 'business'} onChange={handleRadioChange} className="form-radio" />
                                    <span className="text-slate-200">{FORM_LABELS.business}</span>
                                </label>
                            </div>
                        </div>

                        {/* Project/Company Name */}
                         <div className="relative">
                            <input type="text" name="projectName" id="projectName" onChange={handleChange} value={formData.projectName} className={inputClasses} placeholder={FORM_LABELS.projectName} />
                            <label htmlFor="projectName" className={labelClasses}>{FORM_LABELS.projectName}</label>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                             {/* Country */}
                             <div className="relative">
                                <input type="text" name="country" id="country" required onChange={handleChange} value={formData.country} className={inputClasses} placeholder={FORM_LABELS.country} />
                                <label htmlFor="country" className={labelClasses}>{FORM_LABELS.country}</label>
                            </div>
                            {/* Activity Type */}
                            <div className="relative">
                                <select name="activityType" id="activityType" required onChange={handleChange} value={formData.activityType} className={`${inputClasses} placeholder-shown:text-transparent`}>
                                    <option value="" disabled></option>
                                    {ACTIVITY_TYPES.map((type: ActivityType) => (
                                        <option key={type.value} value={type.value}>{type.label}</option>
                                    ))}
                                </select>
                                <label htmlFor="activityType" className={labelClasses}>{FORM_LABELS.activityType}</label>
                            </div>
                        </div>

                        {/* Email */}
                        <div className="relative">
                            <input type="email" name="email" id="email" required onChange={handleChange} value={formData.email} className={inputClasses} placeholder={FORM_LABELS.email} />
                            <label htmlFor="email" className={labelClasses}>{FORM_LABELS.email}</label>
                        </div>
                        
                        {/* WhatsApp */}
                        <div className="relative">
                            <input type="tel" name="whatsapp" id="whatsapp" onChange={handleChange} value={formData.whatsapp} className={inputClasses} placeholder={FORM_LABELS.whatsapp} />
                            <label htmlFor="whatsapp" className={labelClasses}>{FORM_LABELS.whatsapp}</label>
                        </div>

                        {/* Website */}
                        <div className="relative">
                            <input type="url" name="website" id="website" onChange={handleChange} value={formData.website} className={inputClasses} placeholder={FORM_LABELS.website} />
                            <label htmlFor="website" className={labelClasses}>{FORM_LABELS.website}</label>
                        </div>

                        {/* Message */}
                        <div className="relative">
                            <textarea name="message" id="message" rows={4} onChange={handleChange} value={formData.message} className={inputClasses} placeholder={FORM_LABELS.message}></textarea>
                             <label htmlFor="message" className={labelClasses}>{FORM_LABELS.message}</label>
                        </div>
                        
                        {/* Submit Button */}
                        <div>
                            <button type="submit" disabled={status === 'submitting'} className="w-full bg-[#10b981] text-white font-bold py-3 px-8 rounded-lg hover:bg-[#0f9a6d] transition-colors duration-300 disabled:bg-slate-500 disabled:cursor-not-allowed active:scale-95">
                                {status === 'submitting' ? FORM_LABELS.submittingButton : FORM_LABELS.submitButton}
                            </button>
                        </div>
                        
                        {/* Status Messages */}
                        {status === 'success' && <p className="text-center text-green-400 bg-green-900/50 p-3 rounded-md">{FORM_LABELS.successMessage}</p>}
                        {status === 'error' && <p className="text-center text-red-400 bg-red-900/50 p-3 rounded-md">{FORM_LABELS.errorMessage}</p>}
                    </form>
                </div>
            </div>
        </section>
    );
};

export default LeadForm;