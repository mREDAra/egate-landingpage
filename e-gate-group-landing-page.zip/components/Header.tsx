
import React from 'react';
import { COMPANY_NAME, CTA_PRIMARY_TEXT } from '../constants/content';

const EGateLogo: React.FC = () => (
  <div className="flex items-center gap-3">
    <div className="bg-[#10b981] p-1.5 rounded-md">
      <div className="w-6 h-6 bg-[#0A192F] rounded-sm flex items-center justify-center gap-0.5">
        <div className="w-2 h-4 bg-[#10b981] rounded-sm"></div>
        <div className="w-2 h-4 bg-[#10b981] rounded-sm"></div>
      </div>
    </div>
    <span className="text-xl font-bold text-slate-100">{COMPANY_NAME}</span>
  </div>
);

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-[#0A192F]/80 backdrop-blur-lg">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <EGateLogo />
          <a
            href="#lead-form"
            className="hidden sm:inline-block bg-[#10b981] text-white font-bold py-2 px-5 rounded-lg hover:bg-[#0f9a6d] transition-colors duration-300"
          >
            {CTA_PRIMARY_TEXT}
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
