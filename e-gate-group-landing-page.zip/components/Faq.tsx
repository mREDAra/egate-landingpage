
import React, { useState } from 'react';
import { FAQ_SECTION } from '../constants/content';
import { FaqItem } from '../types';

const ChevronDownIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <polyline points="6 9 12 15 18 9"></polyline>
    </svg>
);


const AccordionItem: React.FC<{ item: FaqItem; isOpen: boolean; onToggle: () => void; }> = ({ item, isOpen, onToggle }) => {
    return (
        <div className="border-b border-slate-700">
            <button
                className="w-full flex justify-between items-center text-right py-5"
                onClick={onToggle}
            >
                <span className="text-lg font-medium text-slate-100">{item.question}</span>
                <ChevronDownIcon className={`w-6 h-6 text-slate-400 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            <div
                className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
            >
                <div className="overflow-hidden">
                    <p className="pb-5 text-slate-400">{item.answer}</p>
                </div>
            </div>
        </div>
    );
};

const Faq: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(null);

    const handleToggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <section id="faq" className="py-20 md:py-28">
            <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto">
                    <h2 className="text-3xl md:text-4xl font-extrabold text-slate-100 mb-12">
                        {FAQ_SECTION.title}
                    </h2>
                </div>
                <div className="max-w-3xl mx-auto">
                    {FAQ_SECTION.faqs.map((faq, index) => (
                        <AccordionItem
                            key={index}
                            item={faq}
                            isOpen={openIndex === index}
                            onToggle={() => handleToggle(index)}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Faq;