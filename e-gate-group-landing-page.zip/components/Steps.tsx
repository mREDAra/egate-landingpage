
import React from 'react';
import { STEPS_SECTION } from '../constants/content';
import { Step } from '../types';

const Steps: React.FC = () => {
  return (
    <section id="steps" className="py-20 md:py-28 bg-slate-900/70">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-100 mb-16">
            {STEPS_SECTION.title}
          </h2>
        </div>

        <div className="relative">
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-700/50 transform -translate-y-1/2"></div>
            <div className="relative grid grid-cols-1 md:grid-cols-3 gap-12">
            {STEPS_SECTION.steps.map((step: Step, index: number) => (
                <div key={index} className="text-center">
                    <div className="relative z-10 w-16 h-16 mx-auto mb-6 flex items-center justify-center bg-slate-800 border-2 border-[#10b981] rounded-full text-2xl font-bold text-[#10b981]">
                        {index + 1}
                    </div>
                    <h3 className="text-xl font-bold text-slate-100 mb-2">{step.name}</h3>
                    <p className="text-slate-400">{step.description}</p>
                </div>
            ))}
            </div>
        </div>
      </div>
    </section>
  );
};

export default Steps;
